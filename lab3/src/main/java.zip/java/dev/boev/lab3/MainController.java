package dev.boev.lab3;

import javafx.fxml.FXML;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.Label;
import javafx.stage.DirectoryChooser;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MainController {

    @FXML private ImageView imageView;
    @FXML private Label positionLabel;

    private List<File> files = new ArrayList<>();
    private int currentIndex = 0;

    @FXML
    public void initialize() {
        // Загружаем изображения из ресурсов при старте
        loadResources();
        updateView();
    }

    private void loadResources() {
        // Путь к ресурсам с фото
        String[] imageNames = {"1.jpg", "2.jpg", "3.jpg", "4.jpg", "5.jpg"};

        for (String name : imageNames) {
            try {
                // Загружаем из ресурсов
                java.io.InputStream inputStream = getClass().getResourceAsStream("/dev/boev/lab3/" + name);

                if (inputStream != null) {
                    // Создаём временный файл для совместимости
                    File tempFile = File.createTempFile("img_", ".jpg");
                    tempFile.deleteOnExit();
                    java.nio.file.Files.copy(inputStream, tempFile.toPath(),
                            java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                    files.add(tempFile);
                    inputStream.close();
                }
            } catch (Exception e) {
                System.err.println("Не удалось загрузить: " + name);
            }
        }
    }

    @FXML
    private void onChooseDirectory() {
        DirectoryChooser directoryChooser = new DirectoryChooser();
        directoryChooser.setTitle("Выберите папку с изображениями");

        File selectedDir = directoryChooser.showDialog(imageView.getScene().getWindow());
        if (selectedDir != null) {
            files.clear();
            File[] jpgFiles = selectedDir.listFiles((dir, name) -> name.toLowerCase().endsWith(".jpg"));
            if (jpgFiles != null) {
                for (File f : jpgFiles) {
                    files.add(f);
                }
                files.sort((a, b) -> a.getName().compareTo(b.getName()));
            }
            currentIndex = 0;
            updateView();
        }
    }

    @FXML
    private void onNext() {
        if (files.isEmpty()) return;
        currentIndex = (currentIndex + 1) % files.size();
        updateView();
    }

    @FXML
    private void onPrevious() {
        if (files.isEmpty()) return;
        currentIndex = (currentIndex - 1 + files.size()) % files.size();
        updateView();
    }

    @FXML
    private void onPreview() {
        if (files.isEmpty()) return;

        // Показываем следующее изображение на 500мс
        int previewIndex = (currentIndex + 1) % files.size();
        Image previewImage = ImageLoader.loadFromFile(files.get(previewIndex));

        if (previewImage != null) {
            Image currentImage = imageView.getImage();
            imageView.setOpacity(0.7);
            imageView.setImage(previewImage);

            javafx.animation.PauseTransition pause = new javafx.animation.PauseTransition(
                    javafx.util.Duration.millis(500));
            pause.setOnFinished(e -> {
                imageView.setImage(currentImage);
                imageView.setOpacity(1.0);
            });
            pause.play();
        }
    }

    @FXML
    private void onReset() {
        currentIndex = 0;
        updateView();
    }

    @FXML
    private void onFirst() {
        if (!files.isEmpty()) {
            currentIndex = 0;
            updateView();
        }
    }

    @FXML
    private void onLast() {
        if (!files.isEmpty()) {
            currentIndex = files.size() - 1;
            updateView();
        }
    }

    private void updateView() {
        if (files.isEmpty()) {
            imageView.setImage(null);
            positionLabel.setText("0 из 0");
            return;
        }

        File currentFile = files.get(currentIndex);
        if (currentFile != null) {
            Image image = ImageLoader.loadFromFile(currentFile);
            imageView.setImage(image);
        }

        positionLabel.setText((currentIndex + 1) + " из " + files.size());
    }
}