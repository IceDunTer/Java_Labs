package dev.boev.lab3;

import java.io.File;
import java.io.FilenameFilter;
import java.util.NoSuchElementException;

public class ImageCollection implements Aggregate {
    private File[] files;

    public ImageCollection(File directory) {
        if (directory != null && directory.exists() && directory.isDirectory()) {
            this.files = directory.listFiles(new FilenameFilter() {
                @Override
                public boolean accept(File dir, String name) {
                    return name.toLowerCase().endsWith(".jpg");
                }
            });

            if (this.files != null) {
                java.util.Arrays.sort(this.files);
            }
        } else {
            this.files = new File[0];
        }
    }

    // Конструктор для тестирования
    public ImageCollection(File[] files) {
        this.files = files != null ? files : new File[0];
    }

    @Override
    public Iterator getIterator() {
        return new ImageFileIterator();
    }

    public File getFile(int index) {
        if (files == null || files.length == 0) return null;

        // Circular navigation
        if (index < 0) index = files.length - 1;
        else if (index >= files.length) index = 0;

        return files[index];
    }

    public int size() {
        return files != null ? files.length : 0;
    }

    public boolean isEmpty() {
        return files == null || files.length == 0;
    }

    // Внутренний итератор
    class ImageFileIterator implements Iterator {
        private int currentIndex = 0;

        @Override
        public boolean hasNext() {
            return files != null && files.length > 0;
        }

        @Override
        public Object next() {
            if (!hasNext()) throw new NoSuchElementException("Collection is empty");

            File current = files[currentIndex];
            currentIndex = (currentIndex + 1) % files.length; // circular
            return current;
        }

        @Override
        public Object preview() {
            if (!hasNext()) throw new NoSuchElementException("Collection is empty");
            // Возвращаем следующий элемент, не двигая индекс
            int nextIndex = (currentIndex) % files.length;
            return files[nextIndex];
        }

        @Override
        public boolean haspreview() {
            return files != null && files.length > 0;
        }

        @Override
        public int getCurrentIndex() {
            return currentIndex;
        }

        // Дополнительные методы для удобной навигации
        public void previous() {
            if (!hasNext()) throw new NoSuchElementException("Collection is empty");
            currentIndex = (currentIndex - 1 + files.length) % files.length;
        }

        public void reset() {
            currentIndex = 0;
        }

        public File getCurrentFile() {
            if (!hasNext()) return null;
            return files[currentIndex];
        }

        public String getPositionText() {
            if (!hasNext()) return "0 / 0";
            int displayIndex = (currentIndex == 0 && files.length > 0) ? files.length : currentIndex;
            return displayIndex + " / " + files.length;
        }
    }
}