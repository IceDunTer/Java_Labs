module dev.boev.lab5 {
    requires javafx.controls;
    requires javafx.fxml;
    requires telegrambots.meta;


    opens dev.boev.lab5 to javafx.fxml;
    exports dev.boev.lab5;
    exports dev.boev.lab5.config;
    opens dev.boev.lab5.config to javafx.fxml;
}