package dev.boev.lab5;

import dev.boev.lab5.config.BotConfig;
import dev.boev.lab5.processor.TextProcessor;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;

public class TextProcessorBot extends TelegramLongPollingBot {
    private final TextProcessor processor = new TextProcessor();

    @Override
    public void onUpdateReceived(Update update) {
        if (update.hasMessage() && update.getMessage().hasText()) {
            String text = update.getMessage().getText();
            long chatId = update.getMessage().getChatId();

            String response = text.startsWith("/start")
                    ? "Привет! Отправь текст, я посчитаю слова."
                    : "Слов: " + processor.countWords(text);

            sendMessage(chatId, response);
        }
    }

    private void sendMessage(long chatId, String text) {
        SendMessage msg = new SendMessage();
        msg.setChatId(String.valueOf(chatId));
        msg.setText(text);
        try { execute(msg); } catch (TelegramApiException e) { e.printStackTrace(); }
    }

    @Override
    public String getBotUsername() { return BotConfig.BOT_USERNAME; }
    @Override
    public String getBotToken() { return BotConfig.BOT_TOKEN; }
}