package dev.boev.lab5.config;

public class BotConfig {
    public static final String BOT_USERNAME = "Бот-переворотчик"; // Замените на имя вашего бота
    public static final String BOT_TOKEN = "8331127926:AAHw-RzFpun3pahOi9odxHNjuGOmxB3xl9o"; // Вставьте токен от @BotFather
}