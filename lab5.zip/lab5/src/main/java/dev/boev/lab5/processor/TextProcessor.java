package dev.boev.lab5.processor;

public class TextProcessor {
    public int countWords(String text) {
        if (text == null || text.trim().isEmpty()) return 0;
        return text.trim().split("\\s+").length;
    }
}
